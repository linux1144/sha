import hashlib

text = input("Enter text: ")
print("SHA-1 Digest:", hashlib.sha1(text.encode()).hexdigest())